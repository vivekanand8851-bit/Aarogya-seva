"""
Aarogya Seva Backend API Test Suite
Tests all backend endpoints with comprehensive validation
"""
import requests
import json
import time
import random
import string
from datetime import datetime

# Backend URL from frontend/.env
BASE_URL = "https://wellness-india-4.preview.emergentagent.com/api"

# Admin credentials
ADMIN_EMAIL = "admin@aarogyaseva.com"
ADMIN_PASSWORD = "Aarogya@2025"

# Test state
test_user_email = None
test_user_token = None
test_user_data = None
test_order_id = None
test_order_number = None
test_product_arjuna = None

def generate_test_email():
    """Generate unique test email"""
    timestamp = int(time.time())
    random_str = ''.join(random.choices(string.ascii_lowercase, k=4))
    return f"test_{timestamp}_{random_str}@aarogyaseva.com"

def print_test(test_num, description):
    """Print test header"""
    print(f"\n{'='*80}")
    print(f"TEST {test_num}: {description}")
    print('='*80)

def print_result(success, message, data=None):
    """Print test result"""
    status = "✅ PASS" if success else "❌ FAIL"
    print(f"{status}: {message}")
    if data:
        print(f"Data: {json.dumps(data, indent=2)}")
    return success

def test_1_health_check():
    """Test 1: GET /api/ → status ok"""
    print_test(1, "Health Check API")
    try:
        response = requests.get(f"{BASE_URL}/", timeout=10)
        if response.status_code == 200:
            data = response.json()
            if data.get("status") == "ok":
                return print_result(True, "Health check passed", data)
        return print_result(False, f"Health check failed: {response.status_code} - {response.text}")
    except Exception as e:
        return print_result(False, f"Health check error: {str(e)}")

def test_2_signup():
    """Test 2: POST /api/auth/signup with fresh email → expect token + user with rewardPoints=100"""
    print_test(2, "User Signup with Welcome Points")
    global test_user_email, test_user_token, test_user_data
    
    test_user_email = generate_test_email()
    payload = {
        "name": "Test User",
        "email": test_user_email,
        "phone": "+919876543210",
        "password": "Test@123"
    }
    
    try:
        response = requests.post(f"{BASE_URL}/auth/signup", json=payload, timeout=10)
        if response.status_code == 200:
            data = response.json()
            test_user_token = data.get("token")
            test_user_data = data.get("user")
            
            if not test_user_token:
                return print_result(False, "No token returned")
            if not test_user_data:
                return print_result(False, "No user data returned")
            if test_user_data.get("rewardPoints") != 100:
                return print_result(False, f"Expected 100 welcome points, got {test_user_data.get('rewardPoints')}")
            if test_user_data.get("email") != test_user_email.lower():
                return print_result(False, f"Email mismatch: {test_user_data.get('email')}")
            
            return print_result(True, f"Signup successful with 100 welcome points", {
                "email": test_user_data.get("email"),
                "rewardPoints": test_user_data.get("rewardPoints"),
                "token": test_user_token[:20] + "..."
            })
        return print_result(False, f"Signup failed: {response.status_code} - {response.text}")
    except Exception as e:
        return print_result(False, f"Signup error: {str(e)}")

def test_3_login():
    """Test 3: POST /api/auth/login with same creds → expect token + user"""
    print_test(3, "User Login")
    global test_user_token, test_user_data
    
    payload = {
        "email": test_user_email,
        "password": "Test@123"
    }
    
    try:
        response = requests.post(f"{BASE_URL}/auth/login", json=payload, timeout=10)
        if response.status_code == 200:
            data = response.json()
            test_user_token = data.get("token")
            test_user_data = data.get("user")
            
            if not test_user_token:
                return print_result(False, "No token returned")
            if not test_user_data:
                return print_result(False, "No user data returned")
            
            return print_result(True, "Login successful", {
                "email": test_user_data.get("email"),
                "rewardPoints": test_user_data.get("rewardPoints")
            })
        return print_result(False, f"Login failed: {response.status_code} - {response.text}")
    except Exception as e:
        return print_result(False, f"Login error: {str(e)}")

def test_4_auth_me():
    """Test 4: GET /api/auth/me with Bearer token → returns user"""
    print_test(4, "Get Current User (Auth Me)")
    
    headers = {"Authorization": f"Bearer {test_user_token}"}
    
    try:
        response = requests.get(f"{BASE_URL}/auth/me", headers=headers, timeout=10)
        if response.status_code == 200:
            data = response.json()
            if data.get("email") == test_user_email.lower():
                return print_result(True, "Auth me successful", {
                    "email": data.get("email"),
                    "name": data.get("name"),
                    "rewardPoints": data.get("rewardPoints")
                })
            return print_result(False, f"Email mismatch: {data.get('email')}")
        return print_result(False, f"Auth me failed: {response.status_code} - {response.text}")
    except Exception as e:
        return print_result(False, f"Auth me error: {str(e)}")

def test_5_products_list():
    """Test 5: GET /api/products → seeded 8 products"""
    print_test(5, "List All Products")
    
    try:
        response = requests.get(f"{BASE_URL}/products", timeout=10)
        if response.status_code == 200:
            products = response.json()
            if len(products) == 8:
                return print_result(True, f"Found {len(products)} seeded products", {
                    "count": len(products),
                    "sample": products[0].get("name") if products else None
                })
            return print_result(False, f"Expected 8 products, found {len(products)}")
        return print_result(False, f"Products list failed: {response.status_code} - {response.text}")
    except Exception as e:
        return print_result(False, f"Products list error: {str(e)}")

def test_6_products_filter():
    """Test 6: GET /api/products?category=heart-health → 1 product (Arjuna)"""
    print_test(6, "Filter Products by Category")
    global test_product_arjuna
    
    try:
        response = requests.get(f"{BASE_URL}/products?category=heart-health", timeout=10)
        if response.status_code == 200:
            products = response.json()
            if len(products) == 1:
                product = products[0]
                test_product_arjuna = product
                if "arjuna" in product.get("name", "").lower():
                    return print_result(True, "Found Arjuna in heart-health category", {
                        "name": product.get("name"),
                        "slug": product.get("slug"),
                        "price": product.get("price")
                    })
                return print_result(False, f"Expected Arjuna, got {product.get('name')}")
            return print_result(False, f"Expected 1 product, found {len(products)}")
        return print_result(False, f"Products filter failed: {response.status_code} - {response.text}")
    except Exception as e:
        return print_result(False, f"Products filter error: {str(e)}")

def test_7_product_detail():
    """Test 7: GET /api/products/arjuna-capsules → the product"""
    print_test(7, "Get Product Detail by Slug")
    
    try:
        response = requests.get(f"{BASE_URL}/products/arjuna-capsules", timeout=10)
        if response.status_code == 200:
            product = response.json()
            if product.get("slug") == "arjuna-capsules":
                return print_result(True, "Product detail retrieved", {
                    "name": product.get("name"),
                    "price": product.get("price"),
                    "mrp": product.get("mrp"),
                    "stock": product.get("stock")
                })
            return print_result(False, f"Slug mismatch: {product.get('slug')}")
        return print_result(False, f"Product detail failed: {response.status_code} - {response.text}")
    except Exception as e:
        return print_result(False, f"Product detail error: {str(e)}")

def test_8_order_preview():
    """Test 8: POST /api/orders/preview with 2x arjuna-capsules → verify totals server-computed"""
    print_test(8, "Order Preview with Server-Side Totals")
    
    if not test_product_arjuna:
        return print_result(False, "Arjuna product not loaded from previous test")
    
    headers = {"Authorization": f"Bearer {test_user_token}"}
    payload = {
        "items": [
            {"productId": test_product_arjuna.get("id"), "qty": 2}
        ],
        "address": {
            "name": "Test User",
            "phone": "+919876543210",
            "email": test_user_email,
            "address": "123 Test Street",
            "city": "Mumbai",
            "state": "Maharashtra",
            "pincode": "400001"
        },
        "paymentMethod": "cod",
        "pointsRedeemed": 0
    }
    
    try:
        response = requests.post(f"{BASE_URL}/orders/preview", json=payload, headers=headers, timeout=10)
        if response.status_code == 200:
            data = response.json()
            expected_subtotal = test_product_arjuna.get("price") * 2  # 899 * 2 = 1798
            actual_subtotal = data.get("subtotal")
            
            if actual_subtotal != expected_subtotal:
                return print_result(False, f"Subtotal mismatch: expected {expected_subtotal}, got {actual_subtotal}")
            
            # Verify shipping (free if >= 499)
            expected_shipping = 0 if actual_subtotal >= 499 else 49
            if data.get("shipping") != expected_shipping:
                return print_result(False, f"Shipping mismatch: expected {expected_shipping}, got {data.get('shipping')}")
            
            return print_result(True, "Order preview computed correctly", {
                "subtotal": data.get("subtotal"),
                "shipping": data.get("shipping"),
                "total": data.get("total")
            })
        return print_result(False, f"Order preview failed: {response.status_code} - {response.text}")
    except Exception as e:
        return print_result(False, f"Order preview error: {str(e)}")

def test_9_order_create_cod():
    """Test 9: POST /api/orders (COD, pointsRedeemed=100) → order created, points deducted, earned calculated"""
    print_test(9, "Create COD Order with Points Redemption")
    global test_order_id, test_order_number
    
    headers = {"Authorization": f"Bearer {test_user_token}"}
    payload = {
        "items": [
            {"productId": test_product_arjuna.get("id"), "qty": 1}
        ],
        "address": {
            "name": "Test User",
            "phone": "+919876543210",
            "email": test_user_email,
            "address": "123 Test Street",
            "city": "Mumbai",
            "state": "Maharashtra",
            "pincode": "400001"
        },
        "paymentMethod": "cod",
        "pointsRedeemed": 100
    }
    
    try:
        response = requests.post(f"{BASE_URL}/orders", json=payload, headers=headers, timeout=10)
        if response.status_code == 200:
            data = response.json()
            order = data.get("order")
            
            if not order:
                return print_result(False, "No order returned")
            
            test_order_id = order.get("id")
            test_order_number = order.get("orderNumber")
            
            # Verify points used (100 pts = ₹50)
            if order.get("pointsUsed") != 100:
                return print_result(False, f"Expected 100 points used, got {order.get('pointsUsed')}")
            
            if order.get("redeemValue") != 50:
                return print_result(False, f"Expected ₹50 redeem value, got {order.get('redeemValue')}")
            
            # Verify points earned (5 per ₹100 spent on subtotal)
            subtotal = order.get("subtotal")  # 899
            expected_earned = int(subtotal / 100) * 5  # int(899/100) * 5 = 8 * 5 = 40
            actual_earned = order.get("pointsEarned")
            
            if actual_earned != expected_earned:
                return print_result(False, f"Expected {expected_earned} points earned, got {actual_earned}")
            
            return print_result(True, "COD order created with correct points calculation", {
                "orderNumber": test_order_number,
                "subtotal": subtotal,
                "pointsUsed": order.get("pointsUsed"),
                "redeemValue": order.get("redeemValue"),
                "pointsEarned": actual_earned,
                "total": order.get("total")
            })
        return print_result(False, f"Order creation failed: {response.status_code} - {response.text}")
    except Exception as e:
        return print_result(False, f"Order creation error: {str(e)}")

def test_10_my_orders():
    """Test 10: GET /api/orders → returns order created"""
    print_test(10, "Get My Orders")
    
    headers = {"Authorization": f"Bearer {test_user_token}"}
    
    try:
        response = requests.get(f"{BASE_URL}/orders", headers=headers, timeout=10)
        if response.status_code == 200:
            orders = response.json()
            if len(orders) > 0:
                found = any(o.get("orderNumber") == test_order_number for o in orders)
                if found:
                    return print_result(True, f"Found {len(orders)} order(s) including test order", {
                        "count": len(orders),
                        "testOrderNumber": test_order_number
                    })
                return print_result(False, f"Test order {test_order_number} not found in orders list")
            return print_result(False, "No orders returned")
        return print_result(False, f"My orders failed: {response.status_code} - {response.text}")
    except Exception as e:
        return print_result(False, f"My orders error: {str(e)}")

def test_11_order_detail():
    """Test 11: GET /api/orders/{orderNumber} → returns single order"""
    print_test(11, "Get Single Order by Order Number")
    
    headers = {"Authorization": f"Bearer {test_user_token}"}
    
    try:
        response = requests.get(f"{BASE_URL}/orders/{test_order_number}", headers=headers, timeout=10)
        if response.status_code == 200:
            order = response.json()
            if order.get("orderNumber") == test_order_number:
                return print_result(True, "Order detail retrieved", {
                    "orderNumber": order.get("orderNumber"),
                    "status": order.get("status"),
                    "total": order.get("total")
                })
            return print_result(False, f"Order number mismatch: {order.get('orderNumber')}")
        return print_result(False, f"Order detail failed: {response.status_code} - {response.text}")
    except Exception as e:
        return print_result(False, f"Order detail error: {str(e)}")

def test_12_reward_math():
    """Test 12: Verify reward math: on ₹899 subtotal, earned = int(899/100)*5 = 40 points"""
    print_test(12, "Verify Reward Points Math")
    
    # Get updated user data to verify points
    headers = {"Authorization": f"Bearer {test_user_token}"}
    
    try:
        response = requests.get(f"{BASE_URL}/auth/me", headers=headers, timeout=10)
        if response.status_code == 200:
            user = response.json()
            current_points = user.get("rewardPoints")
            
            # Initial: 100 welcome points
            # Used: 100 points (redeemed)
            # Earned: 40 points (from ₹899 subtotal)
            # Expected: 100 - 100 + 40 = 40 points
            expected_points = 40
            
            if current_points == expected_points:
                return print_result(True, "Reward math verified correctly", {
                    "initialPoints": 100,
                    "pointsUsed": 100,
                    "pointsEarned": 40,
                    "currentPoints": current_points,
                    "calculation": "100 - 100 + 40 = 40"
                })
            return print_result(False, f"Expected {expected_points} points, got {current_points}")
        return print_result(False, f"Failed to get user data: {response.status_code}")
    except Exception as e:
        return print_result(False, f"Reward math verification error: {str(e)}")

def test_13_admin_login():
    """Test 13: POST /api/auth/login with admin credentials → token with isAdmin"""
    print_test(13, "Admin Login")
    global admin_token
    
    payload = {
        "email": ADMIN_EMAIL,
        "password": ADMIN_PASSWORD
    }
    
    try:
        response = requests.post(f"{BASE_URL}/auth/login", json=payload, timeout=10)
        if response.status_code == 200:
            data = response.json()
            admin_token = data.get("token")
            admin_user = data.get("user")
            
            if not admin_token:
                return print_result(False, "No token returned")
            if not admin_user.get("isAdmin"):
                return print_result(False, "User is not admin")
            
            return print_result(True, "Admin login successful", {
                "email": admin_user.get("email"),
                "isAdmin": admin_user.get("isAdmin")
            })
        return print_result(False, f"Admin login failed: {response.status_code} - {response.text}")
    except Exception as e:
        return print_result(False, f"Admin login error: {str(e)}")

def test_14_admin_stats():
    """Test 14: GET /api/admin/stats → returns users/orders/products/revenue"""
    print_test(14, "Admin Stats")
    
    headers = {"Authorization": f"Bearer {admin_token}"}
    
    try:
        response = requests.get(f"{BASE_URL}/admin/stats", headers=headers, timeout=10)
        if response.status_code == 200:
            stats = response.json()
            required_keys = ["users", "orders", "products", "revenue"]
            missing = [k for k in required_keys if k not in stats]
            
            if missing:
                return print_result(False, f"Missing keys: {missing}")
            
            return print_result(True, "Admin stats retrieved", stats)
        return print_result(False, f"Admin stats failed: {response.status_code} - {response.text}")
    except Exception as e:
        return print_result(False, f"Admin stats error: {str(e)}")

def test_15_admin_orders():
    """Test 15: GET /api/admin/orders → all orders"""
    print_test(15, "Admin Get All Orders")
    
    headers = {"Authorization": f"Bearer {admin_token}"}
    
    try:
        response = requests.get(f"{BASE_URL}/admin/orders", headers=headers, timeout=10)
        if response.status_code == 200:
            orders = response.json()
            return print_result(True, f"Admin retrieved {len(orders)} order(s)", {
                "count": len(orders)
            })
        return print_result(False, f"Admin orders failed: {response.status_code} - {response.text}")
    except Exception as e:
        return print_result(False, f"Admin orders error: {str(e)}")

def test_16_admin_users():
    """Test 16: GET /api/admin/users → all users"""
    print_test(16, "Admin Get All Users")
    
    headers = {"Authorization": f"Bearer {admin_token}"}
    
    try:
        response = requests.get(f"{BASE_URL}/admin/users", headers=headers, timeout=10)
        if response.status_code == 200:
            users = response.json()
            return print_result(True, f"Admin retrieved {len(users)} user(s)", {
                "count": len(users)
            })
        return print_result(False, f"Admin users failed: {response.status_code} - {response.text}")
    except Exception as e:
        return print_result(False, f"Admin users error: {str(e)}")

def test_17_admin_update_status():
    """Test 17: PUT /api/admin/orders/{orderId}/status?status=shipped → updates tracking"""
    print_test(17, "Admin Update Order Status")
    
    headers = {"Authorization": f"Bearer {admin_token}"}
    
    try:
        response = requests.put(
            f"{BASE_URL}/admin/orders/{test_order_id}/status?status=shipped",
            headers=headers,
            timeout=10
        )
        if response.status_code == 200:
            data = response.json()
            if data.get("ok"):
                # Verify the update by fetching the order
                order_response = requests.get(
                    f"{BASE_URL}/orders/{test_order_number}",
                    headers={"Authorization": f"Bearer {test_user_token}"},
                    timeout=10
                )
                if order_response.status_code == 200:
                    order = order_response.json()
                    if order.get("status") == "shipped":
                        return print_result(True, "Order status updated to shipped", {
                            "orderNumber": test_order_number,
                            "status": order.get("status")
                        })
                    return print_result(False, f"Status not updated: {order.get('status')}")
                return print_result(False, "Failed to verify status update")
            return print_result(False, "Update returned ok=false")
        return print_result(False, f"Admin update status failed: {response.status_code} - {response.text}")
    except Exception as e:
        return print_result(False, f"Admin update status error: {str(e)}")

def test_18_razorpay_order_expected_error():
    """Test 18: POST /api/orders with razorpay → expect 500 error (test keys)"""
    print_test(18, "Razorpay Order Creation (Expected Error with Test Keys)")
    
    headers = {"Authorization": f"Bearer {test_user_token}"}
    payload = {
        "items": [
            {"productId": test_product_arjuna.get("id"), "qty": 1}
        ],
        "address": {
            "name": "Test User",
            "phone": "+919876543210",
            "email": test_user_email,
            "address": "123 Test Street",
            "city": "Mumbai",
            "state": "Maharashtra",
            "pincode": "400001"
        },
        "paymentMethod": "razorpay",
        "pointsRedeemed": 0
    }
    
    try:
        response = requests.post(f"{BASE_URL}/orders", json=payload, headers=headers, timeout=10)
        if response.status_code == 500:
            error_text = response.text.lower()
            if "razorpay" in error_text:
                return print_result(True, "Expected Razorpay error received (test keys)", {
                    "status": response.status_code,
                    "error": response.text[:200]
                })
            return print_result(False, f"500 error but not Razorpay related: {response.text}")
        return print_result(False, f"Expected 500 error, got {response.status_code}: {response.text}")
    except Exception as e:
        return print_result(False, f"Razorpay order error: {str(e)}")

def test_19_razorpay_verify_invalid():
    """Test 19: POST /api/payment/verify with fake signature → expect 400"""
    print_test(19, "Razorpay Payment Verify with Invalid Signature")
    
    headers = {"Authorization": f"Bearer {test_user_token}"}
    payload = {
        "orderId": test_order_id,
        "razorpay_order_id": "order_fake123",
        "razorpay_payment_id": "pay_fake456",
        "razorpay_signature": "fake_signature_12345"
    }
    
    try:
        response = requests.post(f"{BASE_URL}/payment/verify", json=payload, headers=headers, timeout=10)
        if response.status_code == 400:
            error_text = response.text.lower()
            if "signature" in error_text or "invalid" in error_text:
                return print_result(True, "Invalid signature error received as expected", {
                    "status": response.status_code,
                    "error": response.text
                })
            return print_result(False, f"400 error but not signature related: {response.text}")
        return print_result(False, f"Expected 400 error, got {response.status_code}: {response.text}")
    except Exception as e:
        return print_result(False, f"Payment verify error: {str(e)}")

def run_all_tests():
    """Run all backend tests in sequence"""
    print("\n" + "="*80)
    print("AAROGYA SEVA BACKEND API TEST SUITE")
    print(f"Backend URL: {BASE_URL}")
    print(f"Test Started: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("="*80)
    
    results = []
    
    # Run tests in order
    results.append(("Test 1: Health Check", test_1_health_check()))
    results.append(("Test 2: Signup", test_2_signup()))
    results.append(("Test 3: Login", test_3_login()))
    results.append(("Test 4: Auth Me", test_4_auth_me()))
    results.append(("Test 5: Products List", test_5_products_list()))
    results.append(("Test 6: Products Filter", test_6_products_filter()))
    results.append(("Test 7: Product Detail", test_7_product_detail()))
    results.append(("Test 8: Order Preview", test_8_order_preview()))
    results.append(("Test 9: Create COD Order", test_9_order_create_cod()))
    results.append(("Test 10: My Orders", test_10_my_orders()))
    results.append(("Test 11: Order Detail", test_11_order_detail()))
    results.append(("Test 12: Reward Math", test_12_reward_math()))
    results.append(("Test 13: Admin Login", test_13_admin_login()))
    results.append(("Test 14: Admin Stats", test_14_admin_stats()))
    results.append(("Test 15: Admin Orders", test_15_admin_orders()))
    results.append(("Test 16: Admin Users", test_16_admin_users()))
    results.append(("Test 17: Admin Update Status", test_17_admin_update_status()))
    results.append(("Test 18: Razorpay Order (Expected Error)", test_18_razorpay_order_expected_error()))
    results.append(("Test 19: Razorpay Verify Invalid", test_19_razorpay_verify_invalid()))
    
    # Summary
    print("\n" + "="*80)
    print("TEST SUMMARY")
    print("="*80)
    
    passed = sum(1 for _, result in results if result)
    failed = len(results) - passed
    
    print(f"\nTotal Tests: {len(results)}")
    print(f"✅ Passed: {passed}")
    print(f"❌ Failed: {failed}")
    print(f"\nSuccess Rate: {(passed/len(results)*100):.1f}%")
    
    if failed > 0:
        print("\n❌ FAILED TESTS:")
        for name, result in results:
            if not result:
                print(f"  - {name}")
    
    print("\n" + "="*80)
    print(f"Test Completed: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("="*80 + "\n")
    
    return passed, failed

if __name__ == "__main__":
    passed, failed = run_all_tests()
    exit(0 if failed == 0 else 1)
