import React from 'react';
import './App.css';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { HelmetProvider } from 'react-helmet-async';
import { AppProvider } from './context/AppContext';
import { Toaster } from './components/ui/toaster';
import Announcement from './components/Announcement';
import Navbar from './components/Navbar';
import Footer from './components/Footer';

import HomePage from './pages/HomePage';
import ShopPage from './pages/ShopPage';
import ProductDetailPage from './pages/ProductDetailPage';
import CartPage from './pages/CartPage';
import CheckoutPage from './pages/CheckoutPage';
import WishlistPage from './pages/WishlistPage';
import { BlogListPage, BlogDetailPage } from './pages/BlogPage';
import {
  AboutPage,
  ContactPage,
  ConsultPage,
  LoginPage,
  AccountPage,
  TrackOrderPage,
  PoliciesPage,
} from './pages/StaticPages';
import AdminPage from './pages/AdminPage';

function ScrollToTop() {
  const { pathname } = window.location;
  React.useEffect(() => {
    window.scrollTo(0, 0);
  }, [pathname]);
  return null;
}

function App() {
  return (
    <div className="App bg-[#fbf7ec]">
      <HelmetProvider>
        <AppProvider>
          <BrowserRouter>
            <ScrollToTop />
            <Announcement />
            <Navbar />
            <main>
              <Routes>
                <Route path="/" element={<HomePage />} />
                <Route path="/shop" element={<ShopPage />} />
                <Route path="/product/:slug" element={<ProductDetailPage />} />
                <Route path="/cart" element={<CartPage />} />
                <Route path="/checkout" element={<CheckoutPage />} />
                <Route path="/wishlist" element={<WishlistPage />} />
                <Route path="/blog" element={<BlogListPage />} />
                <Route path="/blog/:id" element={<BlogDetailPage />} />
                <Route path="/about" element={<AboutPage />} />
                <Route path="/contact" element={<ContactPage />} />
                <Route path="/consult" element={<ConsultPage />} />
                <Route path="/login" element={<LoginPage />} />
                <Route path="/account" element={<AccountPage />} />
                <Route path="/track-order" element={<TrackOrderPage />} />
                <Route path="/policies" element={<PoliciesPage />} />
                <Route path="/admin" element={<AdminPage />} />
              </Routes>
            </main>
            <Footer />
            <Toaster />
          </BrowserRouter>
        </AppProvider>
      </HelmetProvider>
    </div>
  );
}

export default App;
